# ============================================================
#  Overhang seat simulation for Danish parliamentary elections
#  Author: MARTIN VINÆS LARSEN
#  Last updated: 2026-03-14
# ============================================================
#
# PURPOSE
# -------
# Estimates the probability that the Social Democrats (A) win one
# or more overhang seats (Danish: "overhængsmandat") at varying
# national vote share levels (20-26%).
#
# An overhang occurs when a party wins more constituency seats
# (kredsmandate, allocated by D'Hondt within each of the 10
# storkredse) than its national proportional entitlement
# (allocated by modified Sainte-Laguë across 175 seats).
#
# METHOD
# ------
# 1. EMPIRICAL NOISE (sigma)
#    Polling-place results from 2019 and 2022 are aggregated to
#    storkreds level. For each stable party (those with >~2%
#    national share in both elections), we compute the log-ratio
#    of observed vs. swing-expected votes in each storkreds.
#    The pooled standard deviation of these centred residuals
#    gives sigma — a data-driven measure of how much a party's
#    geographic vote distribution shifts between elections beyond
#    the national swing.
#    Note: sigma is estimated from stable parties only (A, B, C,
#    F, I, O, V, Ø, Å). New/exiting parties (M, Æ) are excluded
#    because their near-zero base in one election inflates the
#    log-residuals far beyond typical geographic swing noise.
#
# 2. SIMULATION
#    For a given target national vote share for A, all other
#    parties are scaled proportionally from a baseline poll vector.
#    Within each simulation draw (n = 20,000 per scenario):
#      a. Expected storkreds votes are computed by applying national
#         swing factors to 2022 actual storkreds results.
#      b. Multiplicative lognormal noise (sd = sigma) is added to
#         each party × storkreds cell, then renormalised to preserve
#         observed storkreds turnout.
#      c. 135 constituency seats are allocated: first distributed
#         across storkredse proportionally to eligible voters, then
#         within each storkreds by D'Hondt.
#      d. National entitlement is computed by modified Sainte-Laguë
#         (first divisor 1.4) on total national simulated votes.
#      e. Overhang for A = max(0, constituency seats - entitlement).
#    Results reported: P(>=1), P(=1), P(=2), P(=3) overhang seats.
#
# DATA
# ----
# ValgData_FV2019.csv  — polling-place results, 2019 election (and earkuer)
# ValgData_FV2022.csv  — polling-place results, 2022 election
# Source: Valgdatabsen, valg.dst.dk.
# Both files use semicolon delimiters and comma decimal marks.
# Missing values are coded as "-".
#
# REPRODUCTION
# ------------
# Requirements: R >= 4.1, packages: readr, dplyr, tidyr, stringr, purrr
# Install with: install.packages(c("readr","dplyr","tidyr","stringr","purrr"))
# Run with:     Rscript script.R
# (or source the file from an R session)
#
# To change the range of vote shares simulated, edit the `20:26`
# in the lapply() call near the bottom of the script.
# To change the baseline poll, edit the `poll` vector.
# To increase simulation precision, raise `n_sims_per_point`
# (default 20,000; runtime scales linearly).
# ============================================================

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
})

# ----------------------------
# Seat allocation helpers
# ----------------------------
dhondt <- function(votes, seats) {
  n <- length(votes)
  quot <- as.vector(outer(votes, 1:seats, "/"))
  idx <- order(quot, decreasing = TRUE)[1:seats]
  party <- ((idx - 1) %% n) + 1
  tabulate(party, nbins = n)
}

mod_sainte_lague <- function(votes, seats, first_div = 1.4) {
  n <- length(votes)
  divisors <- seq(1, by = 2, length.out = seats)
  divisors[1] <- first_div
  quot <- as.vector(outer(votes, divisors, "/"))
  idx <- order(quot, decreasing = TRUE)[1:seats]
  party <- ((idx - 1) %% n) + 1
  tabulate(party, nbins = n)
}

allocate_constituency_seats <- function(weights, total_seats = 135) {
  quotas <- weights / sum(weights) * total_seats
  seats <- floor(quotas)
  rem <- total_seats - sum(seats)
  rema <- quotas - seats
  add <- order(rema, decreasing = TRUE)[1:rem]
  seats[add] <- seats[add] + 1
  seats
}

# ----------------------------
# Core: read + aggregate to storkreds
# ----------------------------
read_and_aggregate <- function(path, delim = ";", decimal_mark = ",",
                               stork_col, total_col, eligible_col,
                               party_cols_named) {
  # party_cols_named: named character vector:
  # names = short codes (A,B,C,F,I,M,O,Q,V,Æ,Ø,Å,K,D etc)
  # values = exact column names in CSV
  df <- read_delim(path, delim = delim,
                   locale = locale(decimal_mark = decimal_mark),
                   na = c("", "-"),
                   show_col_types = FALSE)
  
  missing <- setdiff(c(stork_col, total_col, eligible_col, unname(party_cols_named)), names(df))
  if (length(missing) > 0) {
    stop("Missing columns in ", path, ":\n", paste(missing, collapse = "\n"))
  }
  
  agg <- df %>%
    group_by(.data[[stork_col]]) %>%
    summarise(
      Total = sum(.data[[total_col]], na.rm = TRUE),
      Eligible = sum(.data[[eligible_col]], na.rm = TRUE),
      across(all_of(unname(party_cols_named)), ~sum(.x, na.rm = TRUE)),
      .groups = "drop"
    ) %>%
    arrange(.data[[stork_col]])
  
  # rename party columns to short codes
  for (code in names(party_cols_named)) {
    old <- party_cols_named[[code]]
    agg[[code]] <- agg[[old]]
    agg[[old]] <- NULL
  }
  
  agg
}

# ----------------------------
# Estimate sigma from two elections
# ----------------------------
estimate_sigma <- function(agg_old, agg_new, parties, eps = 1e-6) {
  # Align storkreds order
  if (!all(agg_old[[1]] == agg_new[[1]])) {
    stop("Storkreds mismatch between the two aggregated datasets.")
  }
  
  old_mat <- as.matrix(agg_old[, parties, drop = FALSE])
  new_mat <- as.matrix(agg_new[, parties, drop = FALSE])
  
  # national swing: expected new = old * (NewNatShare / OldNatShare)
  old_nat <- colSums(old_mat)
  new_nat <- colSums(new_mat)
  
  # Avoid division by zero for tiny/absent parties
  swing <- (new_nat + eps) / (old_nat + eps)
  
  expected_new <- sweep(old_mat, 2, swing, "*")
  
  # residuals in log space: log(obs/exp)
  resid <- log((new_mat + eps) / (expected_new + eps))
  
  # Option: remove party mean residual to focus on dispersion
  resid_centered <- scale(resid, center = TRUE, scale = FALSE)
  
  # sigma as pooled SD across all storkreds×party residuals
  sigma <- sd(as.vector(resid_centered), na.rm = TRUE)
  
  list(sigma = sigma, swing = swing, resid = resid_centered)
}

# ----------------------------
# Build baseline simulation matrix from "new" election
# (the one you want as geography baseline, typically the latest)
# ----------------------------
build_baseline <- function(agg_base,
                           parties_present,   # parties in data
                           proxy_BP = c("D"), # which party column to use as BP proxy
                           include_other = TRUE) {
  
  proxy_BP <- proxy_BP[[1]]
  if (!(proxy_BP %in% names(agg_base))) stop("proxy_BP party not found in baseline data: ", proxy_BP)
  
  # Parties we simulate:
  # Use parties_present plus BP and Other
  parties_sim <- c(parties_present, "BP", "Other")
  
  base <- agg_base %>%
    mutate(
      BP = .data[[proxy_BP]],
      Other = if (include_other) {
        Total - (rowSums(across(all_of(parties_present)), na.rm = TRUE) + BP)
      } else 0
    ) %>%
    select(StorKreds = 1, Total, Eligible, all_of(parties_present), BP, Other)
  
  base_votes <- as.matrix(base[, parties_sim, drop = FALSE])
  stork_totals <- base$Total
  eligible <- base$Eligible
  
  baseline_nat <- colSums(base_votes)
  baseline_share <- baseline_nat / sum(baseline_nat) * 100
  
  list(base = base,
       parties_sim = parties_sim,
       base_votes = base_votes,
       stork_totals = stork_totals,
       eligible = eligible,
       baseline_share = baseline_share)
}

# ----------------------------
# One simulation run for a given target national share vector
# ----------------------------
simulate_overhang_probs <- function(base_votes, stork_totals, const_seats,
                                    parties_sim, baseline_share,
                                    target_share, sigma,
                                    n_sims = 20000, seed = 123,
                                    first_div = 1.4) {
  set.seed(seed)
  
  target_share <- target_share / sum(target_share) * 100
  
  # swing factors per party
  factors <- ifelse(baseline_share > 0, target_share / baseline_share, 0)
  
  idxA <- which(parties_sim == "A")
  overhang <- integer(n_sims)
  
  for (s in 1:n_sims) {
    # Expected votes after swing
    exp_votes <- sweep(base_votes, 2, factors, "*")
    exp_votes <- exp_votes * (stork_totals / rowSums(exp_votes))
    
    # Add multiplicative lognormal noise
    noise <- matrix(rnorm(length(exp_votes), mean = 0, sd = sigma), nrow = nrow(exp_votes))
    sim_votes <- exp_votes * exp(noise)
    
    # Renormalize to keep storkreds totals constant
    sim_votes <- sim_votes * (stork_totals / rowSums(sim_votes))
    
    # Constituency seats (storkreds)
    const_counts <- rep(0L, length(parties_sim))
    for (i in seq_len(nrow(sim_votes))) {
      const_counts <- const_counts + dhondt(sim_votes[i, ], const_seats[i])
    }
    
    # National entitlement (175 DK seats)
    nat_votes <- colSums(sim_votes)
    ent <- mod_sainte_lague(nat_votes, 175, first_div = first_div)
    
    overhang[s] <- max(0L, const_counts[idxA] - ent[idxA])
  }
  
  c(
    p_ge1 = mean(overhang >= 1),
    p1 = mean(overhang == 1),
    p2 = mean(overhang == 2),
    p3 = mean(overhang == 3)
  )
}


# Two inputs: older and newer election (polling place data)
path_old <- "~/Documents/overhang_sims/ValgData_FV2019.csv"
path_new <- "~/Documents/overhang_sims/ValgData_FV2022.csv"

# Column names (year-prefixed in both files)
stork_col    <- "StorKredsNr"
total_col_old    <- "FV2019 - Gyldige stemmer"
total_col_new    <- "FV2022 - Gyldige stemmer"
eligible_col_old <- "FV2019 - Stemmeberettigede"
eligible_col_new <- "FV2022 - Stemmeberettigede"

party_cols_old <- c(
  A  = "FV2019 - A. Socialdemokratiet",
  B  = "FV2019 - B. Radikale Venstre",
  C  = "FV2019 - C. Det Konservative Folkeparti",
  D  = "FV2019 - D. Nye Borgerlige",
  F  = "FV2019 - F. SF - Socialistisk Folkeparti",
  I  = "FV2019 - I. Liberal Alliance",
  K  = "FV2019 - K. Kristendemokraterne",
  M  = "FV2019 - M. Moderaterne",
  O  = "FV2019 - O. Dansk Folkeparti",
  Q  = "FV2019 - Q. Frie Grønne, Danmarks Nye Venstrefløjsparti",
  V  = "FV2019 - V. Venstre, Danmarks Liberale Parti",
  `Æ`= "FV2019 - \u00c6. Danmarksdemokraterne - Inger St\u00f8jberg",
  `Ø`= "FV2019 - \u00d8. Enhedslisten - De R\u00f8d-Gr\u00f8nne",
  `Å`= "FV2019 - \u00c5. Alternativet"
)

party_cols_new <- c(
  A  = "FV2022 - A. Socialdemokratiet",
  B  = "FV2022 - B. Radikale Venstre",
  C  = "FV2022 - C. Det Konservative Folkeparti",
  D  = "FV2022 - D. Nye Borgerlige",
  F  = "FV2022 - F. SF - Socialistisk Folkeparti",
  I  = "FV2022 - I. Liberal Alliance",
  K  = "FV2022 - K. Kristendemokraterne",
  M  = "FV2022 - M. Moderaterne",
  O  = "FV2022 - O. Dansk Folkeparti",
  Q  = "FV2022 - Q. Frie Gr\u00f8nne, Danmarks Nye Venstrefl\u00f8jsparti",
  V  = "FV2022 - V. Venstre, Danmarks Liberale Parti",
  `Æ`= "FV2022 - \u00c6. Danmarksdemokraterne - Inger St\u00f8jberg",
  `Ø`= "FV2022 - \u00d8. Enhedslisten - De R\u00f8d-Gr\u00f8nne",
  `Å`= "FV2022 - \u00c5. Alternativet"
)

# Poll vector (your baseline poll).
# Must include all simulated parties plus BP and Other
poll <- c(A=22.3, F=13.6, I=10.7, V=9.2, `Æ`=8.0, O=7.6, `Ø`=6.6,
          C=6.4, M=6.4, B=4.4, `Å`=2.2, BP=2.2, Q=0.0, K=0.0, Other=0.4)

# Simulation settings
n_sims_per_point <- 20000
seed_base <- 1000
first_divisor <- 1.4

# ============================================================
# RUN
# ============================================================

# Read and aggregate both elections
agg_old <- read_and_aggregate(path_old,
                              stork_col    = stork_col,
                              total_col    = total_col_old,
                              eligible_col = eligible_col_old,
                              party_cols_named = party_cols_old)

agg_new <- read_and_aggregate(path_new,
                              stork_col    = stork_col,
                              total_col    = total_col_new,
                              eligible_col = eligible_col_new,
                              party_cols_named = party_cols_new)

# Parties present in BOTH
common_parties <- intersect(names(party_cols_old), names(party_cols_new))
common_parties <- setdiff(common_parties, c("BP","Other"))  # just in case

# Estimate sigma only from parties with stable >2% national share in BOTH elections.
# New/exiting parties (M, Æ in 2019; P, E in 2019 etc.) cause extreme log-residuals
# that inflate sigma far beyond typical geographic swing noise.
stable_parties <- c("A","B","C","F","I","O","V","\u00d8","\u00c5")

sig_est <- estimate_sigma(agg_old, agg_new, parties = stable_parties)
sigma_hat <- sig_est$sigma
cat(sprintf("\nEstimated sigma (stable parties only): %.4f\n", sigma_hat))

# Build baseline from NEW election (geography).
# D (Nye Borgerlige) is proxied as BP, so exclude it from parties_present
# to avoid double-counting and NA in the poll vector.
parties_for_sim <- setdiff(common_parties, "D")
base_obj <- build_baseline(agg_new, parties_present = parties_for_sim, proxy_BP = "D", include_other = TRUE)

# Constituency seats per storkreds (approx from eligible)
const_seats <- allocate_constituency_seats(base_obj$eligible, total_seats = 135)

# helper: set S to a_share, scale others proportionally (keeping poll ratios)
make_target_for_A <- function(a_share, poll) {
  others <- poll[names(poll) != "A"]
  scale <- (100 - a_share) / sum(others)
  target <- poll
  target["A"] <- a_share
  target[names(others)] <- others * scale
  target
}

# Run points S=20..26
results <- lapply(20:26, function(a) {
  target <- make_target_for_A(a, poll)
  # ensure target has the same order and names as parties_sim
  target <- target[base_obj$parties_sim]
  probs <- simulate_overhang_probs(
    base_votes = base_obj$base_votes,
    stork_totals = base_obj$stork_totals,
    const_seats = const_seats,
    parties_sim = base_obj$parties_sim,
    baseline_share = base_obj$baseline_share,
    target_share = target,
    sigma = sigma_hat,                  # <-- data-driven sigma
    n_sims = n_sims_per_point,
    seed = seed_base + a,
    first_div = first_divisor
  )
  data.frame(S_pct = a, t(probs))
})

tab <- bind_rows(results) %>%
  mutate(across(starts_with("p"), ~round(.x * 100, 2)))

print(tab)